# RailTwin Vercel Prototype

This build is a Vercel-compatible export of the latest RailTwin Department portal UI.

## Important
- It has **no Hatchable runtime dependency**.
- It has **no `/api` serverless functions** and no Hatchable database migrations, so Vercel will not try to compile Hatchable functions.
- Login, request creation, DRM approval, live queue telemetry and block optimization run in the browser using `localStorage`.
- This is therefore a self-contained prototype. Data is stored per browser, not in a shared production database.

## Prototype login
1. Enter any valid email address.
2. Choose Department Login or DRM Login.
3. Use verification code: `260254`.

## Vercel
Deploy the project root. `vercel.json` rewrites `/login` and `/drm` to their static pages.
