const $ = (s) => document.querySelector(s);
const SESSION_KEY = 'railtwin_session_v1';
const REQUESTS_KEY = 'railtwin_requests_v1';
const trains = [
  ['EXP-01','Mumbai → Pune','10:20','ON SCHEDULE'],
  ['HWH-22','Howrah → Mumbai','11:05','PROTECTED'],
  ['FRT-18','Freight Corridor','16:05','REROUTED'],
  ['ICF-07','LTT → ROHA','17:20','ON SCHEDULE']
];
const blocks = [
  ['B-104','KYN–LTT','10:40–11:25','45 min'],
  ['B-118','LTT–PNVL','13:10–14:00','50 min'],
  ['B-126','PNVL–ROHA','16:20–17:05','45 min'],
  ['B-131','ROHA–PUNE','18:10–18:50','40 min'],
  ['B-143','KYN–LTT','20:15–21:00','45 min'],
  ['B-151','LTT–PNVL','21:20–22:00','40 min']
];
let dept = '', selectedTrain = null, selectedBlock = null;

function session(){ try{return JSON.parse(localStorage.getItem(SESSION_KEY)||'null')}catch{return null} }
function readRequests(){
  try {
    const raw = localStorage.getItem(REQUESTS_KEY);
    if(raw) return JSON.parse(raw);
  } catch {}
  const seed = [
    {id:'MR-206',userEmail:'demo@railtwin.local',department:'Track Maintenance',train_id:'EXP-01',train_route:'Mumbai → Pune',block_id:'B-104',block_route:'KYN–LTT',block_time:'10:40–11:25',priority:'HIGH',work_description:'Track defect rectification',status:'PENDING APPROVAL',progress:18,created_at:new Date().toISOString()},
    {id:'MR-207',userEmail:'demo@railtwin.local',department:'Electrical',train_id:'HWH-22',train_route:'Howrah → Mumbai',block_id:'B-118',block_route:'LTT–PNVL',block_time:'13:10–14:00',priority:'CRITICAL',work_description:'Electrical/OHE maintenance',status:'APPROVED',progress:100,created_at:new Date().toISOString()},
    {id:'MR-208',userEmail:'demo@railtwin.local',department:'Signal & Telecom',train_id:'FRT-18',train_route:'Freight Corridor',block_id:'B-126',block_route:'PNVL–ROHA',block_time:'16:20–17:05',priority:'MEDIUM',work_description:'Signal equipment maintenance',status:'UNDER DRM REVIEW',progress:68,created_at:new Date().toISOString()}
  ];
  localStorage.setItem(REQUESTS_KEY, JSON.stringify(seed));
  return seed;
}
function saveRequests(rows){localStorage.setItem(REQUESTS_KEY,JSON.stringify(rows));}
async function init(){
  const s=session();
  if(!s || s.role!=='department'){location.href='/login';return;}
  dept=s.department;
  $('#userEmail').textContent=s.email;
  renderDepartments(); renderTrains(); renderBlocks(); updateSelection(); loadRequests();
  $('#logout').onclick=()=>{localStorage.removeItem(SESSION_KEY);location.href='/login'};
  $('#submit').onclick=submitRequest;
}
function renderDepartments(){
  const ds=[['Track Maintenance','TRACK / ASSET'],['Signal & Telecom','SIGNALS / INTERLOCKING'],['Electrical','OHE / TRACTION'],['Rolling Stock','COACH / LOCOMOTIVE'],['Operations Control','NETWORK / MOVEMENTS']];
  $('#deptList').innerHTML=ds.map(d=>`<div class="dept ${d[0]===dept?'active':'locked'}" data-d="${d[0]}">${d[0]}<span>${d[0]===dept?d[1]:'LOCKED · SIGN OUT TO SWITCH'}</span></div>`).join('');
  document.querySelectorAll('.dept').forEach(x=>x.onclick=()=>{if(x.dataset.d!==dept)alert('This account is locked to '+dept+'. Sign out and use another department account.')});
}
function renderTrains(){
  $('#trains').innerHTML=trains.map((t,i)=>`<div class="train ${selectedTrain===i?'selected':''}" data-i="${i}"><b>${t[0]}</b><small>${t[1]}</small><div class="route">${t[2]} · ${t[3]}</div></div>`).join('');
  document.querySelectorAll('.train').forEach(x=>x.onclick=()=>{selectedTrain=+x.dataset.i;renderTrains();updateSelection()});
}
function renderBlocks(){
  $('#blocks').innerHTML=blocks.map((b,i)=>`<div class="block ${selectedBlock===i?'selected':''}" data-i="${i}"><b>${b[0]}</b><small>${b[1]}</small><div class="time">${b[2]} · ${b[3]}</div><div class="free">● FREE FOR REQUEST</div></div>`).join('');
  document.querySelectorAll('.block').forEach(x=>x.onclick=()=>{selectedBlock=+x.dataset.i;renderBlocks();updateSelection()});
}
function updateSelection(){
  const t=selectedTrain===null?null:trains[selectedTrain], b=selectedBlock===null?null:blocks[selectedBlock];
  $('#selectedTrain').value=t?t[0]+' · '+t[1]:''; $('#selectedBlock').value=b?b[0]+' · '+b[1]+' · '+b[2]:'';
  $('#summary').textContent=t&&b?'Ready to submit '+dept+' request':'Select a train and free block';
  $('#summarySub').textContent=t&&b?'The request will be stored in this browser and shown in the DRM prototype queue.':'Choose both items to continue';
}
function submitRequest(){
  if(selectedTrain===null||selectedBlock===null){alert('Please select a train and a free block.');return;}
  const s=session(), t=trains[selectedTrain], b=blocks[selectedBlock], rows=readRequests();
  const id='MR-'+(209+rows.length);
  rows.push({id,userEmail:s.email,department:dept,train_id:t[0],train_route:t[1],block_id:b[0],block_route:b[1],block_time:b[2],priority:$('#priority').value,work_description:$('#work').value,status:'PENDING APPROVAL',progress:18,created_at:new Date().toISOString()});
  saveRequests(rows); $('#selectionStatus').textContent='PENDING'; $('#selectionStatus').className='status pending'; $('#summary').textContent='Request '+id+' submitted successfully'; $('#summarySub').textContent='Awaiting DRM review.'; $('#submit').textContent='REQUEST SUBMITTED'; setTimeout(()=>$('#submit').textContent='SUBMIT FOR APPROVAL',1800); loadRequests();
}
function loadRequests(){
  const s=session(), rs=readRequests().filter(r=>r.userEmail===s.email);
  $('#mPending').textContent=rs.filter(r=>['PENDING APPROVAL','UNDER DRM REVIEW'].includes(r.status)).length;
  $('#mApproved').textContent=rs.filter(r=>r.status==='APPROVED').length;
  $('#requests').innerHTML=rs.length?rs.map(r=>{const cls=r.status==='APPROVED'?'approved':r.status==='REJECTED'?'rejected':r.status==='UNDER DRM REVIEW'?'review':'pending';return `<div class="reqrow"><b>${r.id}</b><span>${r.train_id}<small>Train</small></span><span>${r.block_id}<small>Block</small></span><span class="prio">${r.priority}</span><div><span class="status ${cls}">${r.status}</span><div class="approvalline"><i style="width:${Number(r.progress||0)}%"></i></div></div></div>`}).join(''):'<div class="empty">No requests yet. Submit a maintenance block request above.</div>';
}
init();
